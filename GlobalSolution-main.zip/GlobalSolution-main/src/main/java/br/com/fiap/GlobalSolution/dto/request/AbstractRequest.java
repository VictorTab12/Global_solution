package br.com.fiap.GlobalSolution.dto.request;

public record AbstractRequest(

        Long id
) {
}
